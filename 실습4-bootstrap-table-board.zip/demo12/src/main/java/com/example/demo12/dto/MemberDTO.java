package com.example.demo12.dto;

public class MemberDTO {
    private long num;
    private String name;
    private String id;
    private String phone;

    public MemberDTO(long num, String name, String id, String phone) {
        this.num = num;
        this.name = name;
        this.id = id;
        this.phone = phone;
    }

    public long getNum() {
        return num;
    }

    public void setNum(long num) {
        this.num = num;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
