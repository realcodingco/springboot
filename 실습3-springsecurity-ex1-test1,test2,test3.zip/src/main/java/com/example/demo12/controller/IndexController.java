package com.example.demo12.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class IndexController {

    @GetMapping(value = "/test1")
    public String test1() {
        return "test1";
    }


    @GetMapping(value = "/test2")
    public String test2() {
        return "test2";
    }


    @GetMapping(value = "/test3")
    public String test3() {
        return "test3";
    }



}
